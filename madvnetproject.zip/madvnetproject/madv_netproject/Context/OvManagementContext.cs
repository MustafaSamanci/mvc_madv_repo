﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using madv_netproject.Models;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace madv_netproject.Context
{
    public class OvManagementContext:DbContext
    {
        public OvManagementContext() : base("OvManagementContextDB")
        {
            
        }

        public DbSet<Owners> Owners { get; set; }
        public DbSet<Vehicles> Vehicles { get; set; }
        public DbSet<Claims> Claims { get; set; }

    }
}