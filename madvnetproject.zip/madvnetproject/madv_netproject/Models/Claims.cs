﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace madv_netproject.Models
{
    public class Claims
    {
        public int Id { get; set; }
        public String Description { get; set; }
        public String Status { get; set; }
        public int Date { get; set; }
        public int Vehicle_Id { get; set; }

        public virtual Vehicles Vehicles { get; set; }

    }
}