﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;

namespace madv_netproject.Models
{
    public class Vehicles
    {
        public int Id { get; set; }

        public String Brand {get; set;}

        public String Vin { get; set;}
        public String Color { get; set; }
        public int Year { get; set; }
        public int Owner_Id { get; set; }

        public virtual Owners Owners { get; set; }

        public virtual ICollection<Claims> Claimss { get; set; }



    }
}